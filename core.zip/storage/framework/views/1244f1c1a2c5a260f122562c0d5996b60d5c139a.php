<div class="card" id="list-view">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Task</th>
                        <th>Project</th>
                        <th>Members</th>
                        <th>Deadline</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="span">
                            <h5 class="m-b-0"><?php echo e($item->name); ?></h5>
                                    <span class="badge badge-pill 
                                    <?php switch($item->status):
                                    case ('incomplete'): ?>
                                    badge-danger
                                    <?php break; ?>
                                    <?php default: ?>
                                    badge-success    
                                    <?php endswitch; ?>
                                    " style="text-transform:capitalize;">
                                    <?php echo e($item->status); ?>

                                </span>
                        </div>
                    </td>
                    <td>
                        <span><?php echo e($item->project->name); ?></span>
                    </td>
                    <td>
                        <div class="d-flex align-items-center">
                            <div>
                                <?php $__currentLoopData = $item->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="m-r-5" href="javascript:void(0);" data-toggle="tooltip" title="<?php echo e($user->name); ?>">
                                    <div class="avatar avatar-image avatar-sm"
                                    <?php if($user->utype == 'MAN'): ?>
                                    style="border: 2px solid gold;"
                                    <?php elseif($user->utype == 'ADM'): ?>
                                    style="border: 2px solid red;"
                                    <?php endif; ?>
                                    >
                                    <img src="<?php echo e(asset('backend/images/user.png')); ?>" alt="<?php echo e($user->name); ?>">
                                </div>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </td>
                <td>
                    <p class="text-success"
                    <?php
                    $today_time = strtotime(Carbon\Carbon::now()->format('d-M-Y'));
                    $expire_time = strtotime(Carbon\Carbon::parse($item->end_date)->format('d-M-Y'));
                    ?> 
                    <?php if($expire_time < $today_time): ?>
                    style="color:red  !important;"
                    <?php endif; ?>
                    >
                    <?php echo e(Carbon\Carbon::parse($item->end_date)->format('d-M-Y')); ?>

                </p>
            </td>
            <td class="text-right">
                <div class="dropdown dropdown-animated scale-left">
                    <a class="text-gray font-size-18" href="javascript:void(0);" data-toggle="dropdown">
                        <i class="anticon anticon-setting"></i>
                    </a>
                    <div class="dropdown-menu">
                        <a href="<?php echo e(route('tasks.show', $item->id)); ?>" class="dropdown-item" type="button">
                            <i class="anticon anticon-eye"></i>
                            <span class="m-l-10">View</span>
                        </a>
                        <button class="dropdown-item" type="button" onclick="
                        navigator.clipboard.writeText('<?php echo e(route('share.task', $item->id)); ?>')
                        alert('Copied Link!')
                        ">
                            <i class="anticon anticon-link"></i>
                            <span class="m-l-10">Copy Link</span>
                        </button>
                        <a href="<?php echo e(route('tasks.change.status', $item->id)); ?>" class="dropdown-item" type="button">
                            <i class="anticon anticon-check"></i>
                            <span class="m-l-10">Update Status</span>
                        </a>
                        <a href="<?php echo e(route('tasks.edit', $item->id)); ?>" class="dropdown-item" type="button">
                            <i class="anticon anticon-edit"></i>
                            <span class="m-l-10">Edit</span>
                        </a>
                        <button class="dropdown-item" type="button" onclick="if(confirm('Are you sure you want to delete this data?')){document.getElementById('delete-form<?php echo e($item->id); ?>').submit(); }">
                            <i class="anticon anticon-delete"></i>
                            <span class="m-l-10">Delete</span>
                        </button>
                        <form style="display: none;" id="delete-form<?php echo e($item->id); ?>" method="POST" action="<?php echo e(route('tasks.destroy', $item->id)); ?>" >
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        </form>
                    </div>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>
</table>
</div>
</div>
</div><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/tasks/style/list-view.blade.php ENDPATH**/ ?>