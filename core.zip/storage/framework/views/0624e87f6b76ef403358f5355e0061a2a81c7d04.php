<!-- Modal -->
<div class="modal modal-right fade " id="filter">
    <div class="modal-dialog" >
      <div class="modal-content">
        <form action="<?php echo e(route('activity.log')); ?>" method="post">
          <?php echo csrf_field(); ?> <?php echo method_field("GET"); ?>
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalCenterTitle">Filter Activity</h5>
            
          </div>
          
          <div class="modal-body" style="overflow-y: auto; overflow-x: hidden;">
            
            
            
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label for="ceated_at">Date</label>
                  <input type="date"
                  class="form-control" name="ceated_at" id="ceated_at" aria-describedby="helpId" placeholder="" value="<?php echo e(request()->get('ceated_at','')); ?>">
                </div>
              </div>
              
            </div>            
            
            
          </div>
          <div class="modal-footer" >
            <a type="button" class="btn btn-default mr-3" href="<?php echo e(route('projects.index')); ?>">Reset</a>
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
          
        </form>
      </div>
    </div>
  </div><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/activity_filter_form.blade.php ENDPATH**/ ?>