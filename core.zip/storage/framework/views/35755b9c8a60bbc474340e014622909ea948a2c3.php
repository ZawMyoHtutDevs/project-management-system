
<?php $__env->startSection('style'); ?>
<link href="https://unpkg.com/dropzone@6.0.0-beta.1/dist/dropzone.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div class="media align-items-center">
                            
                            <div class="m-l-1">
                                <h4 class="m-b-0"><?php echo e($project->name); ?></h4>
                                <p><?php echo e($project->category->name); ?></p>
                            </div>
                        </div>
                        <div>
                            <span class="badge badge-pill 
                            <?php switch($project->status):
                            case ('not started'): ?>
                            badge-default
                            <?php break; ?>
                            <?php case ('in progress'): ?>
                            badge-info
                            <?php break; ?>
                            <?php case ('on hold'): ?>
                            badge-warning
                            <?php break; ?>
                            <?php case ('cancled'): ?>
                            badge-dange
                            <?php break; ?>
                            <?php default: ?>
                            badge-success    
                            <?php endswitch; ?>
                            " style="text-transform:capitalize;"><?php echo e($project->status); ?></span>
                            <span class="badge badge-pill badge-info" style="text-transform:capitalize;"><?php echo e($project->priority); ?></span>
                        </div>
                    </div>
                    
                    <div class="d-md-flex m-t-30 align-items-center justify-content-between">
                        <div class="d-flex align-items-center m-t-10">
                            <span class="text-dark font-weight-semibold m-r-10 m-b-5">Team: </span>
                            <?php $__currentLoopData = $project->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                <span class="badge badge-pill 
                                <?php if($user->utype == 'MAN'): ?>
                                    badge-warning
                                <?php elseif($user->utype == 'ADM'): ?>
                                    badge-danger
                                <?php else: ?>
                                    badge-default
                                <?php endif; ?>
                                "><?php echo e($user->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="m-t-10">
                        <span class="font-weight-semibold m-r-10 m-b-5 text-dark">Start Date: </span>
                        <span><?php echo e(Carbon\Carbon::parse($project->start_date)->format('d-M-Y')); ?> </span><br>
                        <span class="font-weight-semibold m-r-10 m-b-5 text-dark">Deadline: </span>
                        <span><?php echo e(Carbon\Carbon::parse($project->end_date)->format('d-M-Y')); ?> </span>
                    </div>
                </div>
            </div>
            <div class="m-t-30">
                <ul class="nav nav-tabs" id="myTab">
                    <li class="nav-item">
                        <a class="nav-link "  href="<?php echo e(route('projects.show', $project->id)); ?>">Overview</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('projects.index')); ?>/<?php echo e($project->id); ?>/tasks">Tasks</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('projects.index')); ?>/<?php echo e($project->id); ?>/comments">Comments</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link active" href="<?php echo e(route('projects.index')); ?>/<?php echo e($project->id); ?>/attachments">Attachments</a>
                    </li>
                </ul>
                <div class="tab-content m-t-15 p-25">
                    <div class="tab-pane fade show active" id="project-details-attachment">

                        
                        <?php if(Session::has('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                <span class="sr-only">Close</span>
                            </button>
                            <?php echo e(Session::get('success')); ?>

                        </div>
                        <?php endif; ?>

                        <small>Max upload file size is 50MB.</small>
                        <div class="m-3">
                            <div id="file" class="dropzone"></div>
                        </div>
                        
                        <?php $__currentLoopData = $attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="file" style="min-width: 200px;">
                            <div class="media align-items-center">
                                <?php if($item->extension == "png" || $item->extension == "jpg" || $item->extension == "jpeg" || $item->extension == "gif" ): ?>
                                <div class="avatar avatar-icon avatar-blue rounded m-r-15">
                                    <i class="anticon anticon-file-image font-size-20"></i>
                                </div>
                                
                                <?php elseif($item->extension == "docx" || $item->extension == "txt"): ?>
                                <div class="avatar avatar-icon avatar-cyan rounded m-r-15">
                                    <i class="anticon anticon-file-text font-size-20"></i>
                                </div>
                                
                                <?php elseif($item->extension == "pdf"): ?>
                                <div class="avatar avatar-icon avatar-volcano rounded m-r-15">
                                    <i class="anticon anticon-file-pdf font-size-20"></i>
                                </div>
                                
                                <?php else: ?>
                                <div class="avatar avatar-icon avatar-gold rounded m-r-15">
                                    <i class="anticon anticon-file-exclamation font-size-20"></i>
                                </div>
                                
                                <?php endif; ?>
                                
                                
                                <div>
                                    <h6 class="mb-0"><?php echo e($item->asset); ?></h6>
                                    <span class="font-size-13 text-muted">
                                        <?php
                                        if ($item->size >= 1073741824) {
                                            $mbSize = number_format($item->size / 1073741824, 2) . ' GB';
                                        } elseif ($item->size >= 1048576) {
                                            $mbSize = number_format($item->size / 1048576, 2) . ' MB';
                                        } elseif ($item->size >= 1024) {
                                            $mbSize = number_format($item->size / 1024, 2) . ' KB';
                                        } elseif ($item->size > 1) {
                                            $mbSize = $item->size . ' bytes';
                                        } elseif ($item->size == 1) {
                                            $mbSize = '1 byte';
                                        } else {
                                            $mbSize = '0 bytes';
                                        }
                                        ?>
                                        <?php echo e($mbSize); ?></span>
                                        <span class="float-right">
                                            <a href="<?php echo e(asset('backend/images/projects/'. $item->asset)); ?>" class="badge badge-pill badge-blue" download>Downlaod</a>
                                            
                                            <span class="badge badge-pill badge-red" onclick="if(confirm('Are you sure you want to delete this data?')){document.getElementById('delete-form<?php echo e($item->id); ?>').submit(); }">Delete</span>
                                            
                                            <form style="display: none;" id="delete-form<?php echo e($item->id); ?>" method="POST" action="<?php echo e(route('attachment.destroy', $item->id)); ?>" >
                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            </form>
                                            
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Content Wrapper END -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://unpkg.com/dropzone@6.0.0-beta.1/dist/dropzone-min.js"></script>
<script>
    var drop = new Dropzone('#file', {
        createImageThumbnails: true,
        addRemoveLinks: true,
        url: "<?php echo e(route('attachment.storeProject', $project->id)); ?>",
        headers: {
            'X-CSRF-TOKEN': document.head.querySelector('meta[name="csrf-token"]').content
        }
    });
    
    // $('#myTab a[href="#project-details-comments"]').tab('show')
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/projects/show/attachments.blade.php ENDPATH**/ ?>