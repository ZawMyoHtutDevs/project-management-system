<div>
    Hello <?php echo e($email_data['userName']); ?>,
    <br>
    <p>
        New Task Assigned to You
    </p>
    <p>Task Name : <?php echo e($email_data['name']); ?></p>
    <p>Task Deadline : <?php echo e($email_data['end_date']); ?></p><br>

    <san>Regards,</san>
    <p>41 Dev</p>
</div><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/emails/tasks.blade.php ENDPATH**/ ?>