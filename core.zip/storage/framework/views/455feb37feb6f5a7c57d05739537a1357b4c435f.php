
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-9">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div class="media align-items-center">
                                
                                <div class="m-l-1">
                                    <h4 class="m-b-0"><?php echo e($task->name); ?></h4>
                                    <p><?php echo e($task->taskCategory->name); ?></p>
                                </div>
                            </div>
                            <div>
                                <span class="badge badge-pill 
                                    <?php switch($task->status):
                                        case ('incomplete'): ?>
                                            badge-danger
                                            <?php break; ?>
                                        <?php default: ?>
                                            badge-success    
                                    <?php endswitch; ?>
                                    " style="text-transform:capitalize;"><?php echo e($task->status); ?></span>
                                <span class="badge badge-pill badge-info" style="text-transform:capitalize;"><?php echo e($task->priority); ?></span>
                            </div>
                        </div>
                        
                        <div class="d-md-flex m-t-30 align-items-center justify-content-between">
                            <div class="d-flex align-items-center m-t-10">
                                <span class="text-dark font-weight-semibold m-r-10 m-b-5">Team: </span>
                                <?php $__currentLoopData = $task->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                <span class="badge badge-pill 
                                <?php if($user->utype == 'MAN'): ?>
                                    badge-warning
                                <?php elseif($user->utype == 'ADM'): ?>
                                    badge-danger
                                <?php else: ?>
                                    badge-default
                                <?php endif; ?>
                                "><?php echo e($user->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="m-t-10">
                                <span class="font-weight-semibold m-r-10 m-b-5 text-dark">Start Date: </span>
                                <span><?php echo e(Carbon\Carbon::parse($task->start_date)->format('d-M-Y')); ?> </span><br>
                                <span class="font-weight-semibold m-r-10 m-b-5 text-dark">Deadline: </span>
                                <span><?php echo e(Carbon\Carbon::parse($task->end_date)->format('d-M-Y')); ?> </span>
                            </div>
                        </div>
                    </div>
                    <div class="m-t-30">
                        <ul class="nav nav-tabs" id="myTab">
                            <li class="nav-item">
                                <a class="nav-link "  href="<?php echo e(route('tasks.show', $task->id)); ?>">Overview</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('tasks.index')); ?>/<?php echo e($task->id); ?>/timers">Timers</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" href="<?php echo e(route('tasks.index')); ?>/<?php echo e($task->id); ?>/comments">Comments</a>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link " href="<?php echo e(route('tasks.index')); ?>/<?php echo e($task->id); ?>/attachments">Attachments</a>
                            </li>
                        </ul>
                        <div class="tab-content tab-content m-t-1 p-10">
                            <div class="tab-pane fade show active" id="task-details-attachment">
                                <div class="text-md-right mb-2">
                                    <button class="btn btn-primary m-r-5 ml-2 " data-toggle="modal" data-target="#commentModel">
                                        <i class="anticon anticon-message"></i>
                                        <span class="m-l-5">Write Comment</span>
                                    </button>
                                </div>
                                <ul class="list-group list-group-flush">
                                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item p-h-0">
                                        <div class="media m-b-1">
                                            
                                            <div class="media-body m-l-20">
                                                <h6 class="m-b-0">
                                                    <a href="" class="text-dark"><?php echo e($item->user->name); ?></a>
                                                </h6>
                                                <span class="font-size-13 text-gray"><?php echo e(Carbon\Carbon::parse($item->created_at)->format('d-M-Y')); ?></span>
                                            </div>
                                        </div>
                                        <div class="ml-3"><?php echo $item->comment; ?></div>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <h3>Project</h3>
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div class="media">
                                
                                <div class="m-l-1">
                                    <h5 class="m-b-0"><?php echo e($task->project->name); ?></h5>
                                </div>
                            </div>
                            <div class="dropdown dropdown-animated scale-left">
                                <a class="text-gray font-size-18" href="javascript:void(0);" data-toggle="dropdown">
                                    <i class="anticon anticon-setting"></i>
                                </a>
                                <div class="dropdown-menu">
                                    <a href="<?php echo e(route('projects.show', $task->project->id)); ?>" class="dropdown-item" type="button">
                                        <i class="anticon anticon-eye"></i>
                                        <span class="m-l-10">View</span>
                                    </a>
                                    
                                </div>
                            </div>
                        </div>
                        <p class="mt-3">
                            <span class="font-weight-semibold m-r-10 m-b-5 text-dark">Start Date: </span>
                                <span><?php echo e(Carbon\Carbon::parse($task->project->start_date)->format('d-M-Y')); ?> </span><br>
                                <span class="font-weight-semibold m-r-10 m-b-5 text-dark">Deadline: </span>
                                <span><?php echo e(Carbon\Carbon::parse($task->project->end_date)->format('d-M-Y')); ?> </span>
                        </p>
                        
                        <div class="m-t-20">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    
                                    <span class="badge badge-pill 
                                    <?php switch($task->project->status):
                                        case ('not started'): ?>
                                            badge-default
                                            <?php break; ?>
                                        <?php case ('in progress'): ?>
                                            badge-info
                                            <?php break; ?>
                                        <?php case ('on hold'): ?>
                                            badge-warning
                                            <?php break; ?>
                                        <?php case ('cancled'): ?>
                                            badge-dange
                                            <?php break; ?>
                                        <?php default: ?>
                                            badge-success    
                                    <?php endswitch; ?>
                                    " style="text-transform:capitalize;"><?php echo e($task->project->status); ?></span>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- Content Wrapper END -->


<div class="modal fade" id="commentModel">
    <div class="modal-dialog modal-dialog-centered">
        <!-- Modal -->
        <form method="POST" action="<?php echo e(route('comments.store')); ?>" >
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                
                <div class="modal-body">
                    <div class="form-group">
                        <input type="hidden" name="type" value="App\Models\Task">
                        <input type="hidden" name="id" value="<?php echo e($task->id); ?>">
                        <textarea name="comment" class="form-control  <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="comment" rows="3"><?php echo old('comment'); ?></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Post Comment</button>
                </div>
            </div>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="//cdn.ckeditor.com/4.19.0/standard/ckeditor.js"></script>

<script>
    
    CKEDITOR.replace( 'comment',{
        
    } 
    );
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/tasks/show/comments.blade.php ENDPATH**/ ?>