<footer class="footer">
    <div class="footer-content">
        <p class="m-b-0">Copyright © 2022. All rights reserved.</p>
        
    </div>
</footer><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/layouts/parts/footer.blade.php ENDPATH**/ ?>