<!-- Modal -->
<div class="modal modal-right fade " id="filter">
    <div class="modal-dialog" >
        <div class="modal-content">
                    <form action="<?php echo e(route('tasks.index')); ?>" method="post">
                            <?php echo csrf_field(); ?> <?php echo method_field("GET"); ?>
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalCenterTitle">Filter Tasks</h5>
                            
                        </div>

                        <div class="modal-body" style="overflow-y: auto; overflow-x: hidden;">
                            
                                <div class="form-group">
                                  <label for="">Task Name</label>
                                  <input type="text"
                                    class="form-control" name="name" id="name" value="<?php echo e(request()->get('name','')); ?>" aria-describedby="helpId" placeholder="">
                                </div>

                                <div class="row">
                                  <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="start_date">Start Date</label>
                                        <input type="date"
                                          class="form-control" name="start_date" id="start_date" aria-describedby="helpId" placeholder="" value="<?php echo e(request()->get('start_date','')); ?>">
                                    </div>
                                  </div>
                                  <div class="col-md-6">
                                    <div class="form-group">
                                      <label for="">Deadline</label>
                                      <input type="date"
                                        class="form-control" name="end_date" id="end_date" aria-describedby="helpId" placeholder="" value="<?php echo e(request()->get('end_date','')); ?>">
                                  </div>
                                  </div>
                                </div>


                                <div class="form-group">
                                  <label for="end_date_orderby">Sort with Deadline</label>
                                  <select class="form-control" name="end_date_orderby" id="end_date_orderby" style="text-transform:capitalize;">
                                    
                                    <?php if(request()->get('end_date_orderby') == "asc"): ?>
                                    <option value="<?php echo e(request()->get('status','')); ?>">ascending</option>
                                    <?php elseif(request()->get('end_date_orderby') == "desc"): ?>
                                    <option value="<?php echo e(request()->get('status','')); ?>">descending</option>
                                    <?php else: ?>
                                    <option value="">Select Order</option>
                                    <?php endif; ?>
                                    <option value="asc">ascending</option>
                                    <option value="desc">descending</option>
                                  </select>
                                </div>

                                
                                <div class="form-group">
                                    <label for="category_id">Task Category</label>
                                    <select class="select2" name="category_id" id="category_id">
                                        <option value="">Select</option>
                                      <?php $__currentLoopData = $taskCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($cat_data->id); ?>"><?php echo e($cat_data->name); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                               

                                <div class="row">
                                  <div class="col-md-6">

                                    <div class="form-group">
                                      <label for="status">Project Status</label>
                                      <select class="form-control" name="status" id="status" style="text-transform:capitalize;">
                                        <?php if(request()->get('status')): ?>
                                            <option value="<?php echo e(request()->get('status','')); ?>"><?php echo e(request()->get('status','')); ?></option>
                                        <?php else: ?>
                                        <option value="">Select Status</option>
                                        <?php endif; ?>

                                        <option value="not started">not started</option>
                                        <option value="in progress">in progress</option>
                                        <option value="on hold">on hold</option>
                                        <option value="cancled">cancled</option>
                                        <option value="finished">finished</option>
                                      </select>
                                    </div>
                                  </div>
                                  <div class="col-md-6">

                                    <div class="form-group">
                                      <label for="priority">Project Priority</label>
                                      <select class="form-control" name="priority" id="priority" style="text-transform:capitalize;">
                                        <?php if(request()->get('priority')): ?>
                                            <option value="<?php echo e(request()->get('priority','')); ?>"><?php echo e(request()->get('priority','')); ?></option>
                                        <?php else: ?>
                                        <option value="">Select Priority</option>
                                        <?php endif; ?>
                                        <option value="high">high</option>
                                        <option value="medium">medium</option>
                                        <option value="low">low</option>
                                      </select>
                                  </div>
                                  </div>
                                </div>
                            
                        </div>
                        <div class="modal-footer" style="position: sticky; background-color: white;">
                            <a type="button" class="btn btn-default mr-3" href="<?php echo e(route('projects.index')); ?>">Reset</a>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>

                    </form>
        </div>
    </div>
</div><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/tasks/filter_form.blade.php ENDPATH**/ ?>