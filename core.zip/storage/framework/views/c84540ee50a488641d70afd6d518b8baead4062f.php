

<?php $__env->startSection('style'); ?>
<!-- select css -->
<link href="<?php echo e(asset('backend/vendors/select2/select2.css')); ?>"  rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



<div class="page-header no-gutters">
    <div class="row align-items-md-center">
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-5">
                    <h3>Tasks</h3>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="text-md-right m-v-10">
                <span class="text-muted pr-3 pt-2 p">Total Result: <?php echo e(count($tasks)); ?></span>

                <div class="btn-group m-r-10">
                    <a href="<?php echo e(route('task.style', 'list')); ?>" id="list-view-btn" type="button" class="btn btn-default btn-icon pt-2
                    <?php if(session()->get('taskstyle')): ?>
                        <?php if(session()->get('taskstyle') == 'list'): ?>
                        active 
                        <?php endif; ?>
                    <?php endif; ?>
                    "  title="List View">
                        <i class="anticon anticon-ordered-list"></i>
                    </a>
                    <a href="<?php echo e(route('task.style', 'grid')); ?>" id="card-view-btn" type="button" class="btn btn-default btn-icon pt-2 
                    <?php if(session()->get('taskstyle')): ?>
                        <?php if(session()->get('taskstyle') == 'grid'): ?>
                        active 
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    "  title="Card View">
                        <i class="anticon anticon-appstore"></i>
                    </a>
                </div>


                <button class="btn btn-default m-r-5 " data-toggle="modal" data-target="#filter" >
                    <i class="anticon anticon-filter"></i>
                    <span class="m-l-5">Filter</span>
                </button>
                
                <a href="<?php echo e(route('tasks.create.one')); ?>" class="btn btn-primary m-r-5 ml-2 " >
                    <i class="anticon anticon-plus"></i>
                    <span class="m-l-5">New Task</span>
                </a>

            </div>
        </div>
    </div>
</div>        
   

<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        <span class="sr-only">Close</span>
    </button>
    <?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        <span class="sr-only">Close</span>
    </button>
    <?php echo e(Session::get('error')); ?>

</div>
<?php endif; ?>


<div class="container-fluid">
    <?php switch(session()->get('taskstyle')):
        case ('grid'): ?>
            <?php echo $__env->make('tasks.style.grid-view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
        <?php case ('list'): ?>
            <?php echo $__env->make('tasks.style.list-view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
        <?php default: ?>
            <?php echo $__env->make('tasks.style.grid-view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endswitch; ?>
    
    <?php echo $tasks->appends(array("name" => request()->get('name',''), "status" => request()->get('status',''), "start_date" => request()->get('start_date',''), "end_date" => request()->get('end_date',''), "end_date_orderby" => request()->get('end_date_orderby',''), "task_category_id" => request()->get('task_category_id',''), "priority" => request()->get('priority','') ))->links(); ?>

</div>


<?php echo $__env->make('tasks.filter_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- select js -->
<script src="<?php echo e(asset('backend/vendors/select2/select2.min.js')); ?>"></script>

<script>
    $('.select2').select2();
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/tasks/index.blade.php ENDPATH**/ ?>