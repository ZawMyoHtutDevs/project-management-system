
<?php $__env->startSection('style'); ?>
<!-- select css -->
<link href="<?php echo e(asset('backend/vendors/select2/select2.css')); ?>"  rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header">
    <h2 class="header-title">Step One</h2>
    <div class="header-sub-title">
        <nav class="breadcrumb breadcrumb-dash">
            <a href="<?php echo e(route('home')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Dashboard</a>
            <a class="breadcrumb-item" href="<?php echo e(route('tasks.index')); ?>">Tasks</a>
            <span class="breadcrumb-item active">New Task</span>
        </nav>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            
            <div class="card-body">
                
                <div class="form-group">
                    <label for="project_id">Projects</label>
                    <select class="select2" name="project_id" id="project_id" onchange="GetId()">
                        <option value="">Select Project</option>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </select>
                </div>
                
                <hr>
                
                <div id="submitButton">
                    
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- select js -->
<script src="<?php echo e(asset('backend/vendors/select2/select2.min.js')); ?>"></script>
<script>
    $('.select2').select2();

    window.onload = function() {
        document.getElementById('submitButton').innerHTML = "<button disabled='' class='btn btn-primary m-r-5 ml-2 float-right' id='nextStep'><span class='m-l-5'>Next Step</span><i class='anticon anticon-right'></i></button>"
    };

    function GetId(){
        $projectId = document.getElementById('project_id').value;
        if($projectId == ''){
            document.getElementById('submitButton').innerHTML = "<button disabled='' class='btn btn-primary m-r-5 ml-2 float-right' id='nextStep'><span class='m-l-5'>Next Step</span><i class='anticon anticon-right'></i></button>"
        }else{
        document.getElementById('submitButton').innerHTML = "<a href='<?php echo e(url('dashboard/tasks/create/step/2')); ?>/"+$projectId+"' class='btn btn-primary m-r-5 ml-2 float-right' id='nextStep'><span class='m-l-5'>Next Step</span><i class='anticon anticon-right'></i></a>"
        }
    }
    
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/tasks/create_one.blade.php ENDPATH**/ ?>