

<?php $__env->startSection('style'); ?>
<!-- page css -->
<link href="<?php echo e(asset('backend/vendors/datatables/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header">
    <h2 class="header-title"><?php echo e($client->name); ?></h2>
    <div class="header-sub-title">
        <nav class="breadcrumb breadcrumb-dash">
            <a href="<?php echo e(route('home')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Dashboard</a>
            <a class="breadcrumb-item" href="<?php echo e(route('clients.index')); ?>">Clients</a>
            <span class="breadcrumb-item active">Client Detail</span>
        </nav>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div class="row align-items-center">
            <div class="col-md-7">
                <div class="d-md-flex align-items-center">
                    <div class="text-center text-sm-left ">
                        <div class="avatar avatar-image" style="width: 150px; height:150px">
                            <img src="
                            <?php if(!empty($client->asset)): ?>
                                <?php echo e(asset('backend/images/clients/'. $client->asset)); ?>

                            <?php else: ?>
                                <?php echo e(asset('backend/images/client_logo.png')); ?>

                            <?php endif; ?>
                            " alt="">
                        </div>
                    </div>
                    <div class="text-center text-sm-left m-v-15 p-l-30">
                        <h2 class="m-b-5"><?php echo e($client->name); ?></h2>
                        <p class="text-dark m-b-20"><?php echo e($client->description); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="row">
                    <div class="d-md-block d-none border-left col-1"></div>
                    <div class="col">
                        <ul class="list-unstyled m-t-10">
                            <li class="row">
                                <p class="col-sm-4 col-4 font-weight-semibold text-dark m-b-5">
                                    <i class="m-r-10 text-primary anticon anticon-mail"></i>
                                    <span>Email: </span> 
                                </p>
                                <p class="col font-weight-semibold"> <?php echo e($client->email); ?></p>
                            </li>
                            <li class="row">
                                <p class="col-sm-4 col-4 font-weight-semibold text-dark m-b-5">
                                    <i class="m-r-10 text-primary anticon anticon-user"></i>
                                    <span>Client: </span> 
                                </p>
                                <p class="col font-weight-semibold"> <?php echo e($client->contact_person); ?></p>
                            </li>
                            <li class="row">
                                <p class="col-sm-4 col-4 font-weight-semibold text-dark m-b-5">
                                    <i class="m-r-10 text-primary anticon anticon-phone"></i>
                                    <span>Phone: </span> 
                                </p>
                                <p class="col font-weight-semibold"> <?php echo e($client->phone); ?></p>
                            </li>
                            <li class="row">
                                <p class="col-sm-4 col-4 font-weight-semibold text-dark m-b-5">
                                    <i class="m-r-10 text-primary anticon anticon-global"></i>
                                    <span>Website: </span> 
                                </p>
                                <p class="col font-weight-semibold"> <?php echo e($client->website); ?></p>
                            </li>
                            <li class="row">
                                <p class="col-sm-4 col-5 font-weight-semibold text-dark m-b-5">
                                    <i class="m-r-10 text-primary anticon anticon-compass"></i>
                                    <span>Location: </span> 
                                </p>
                                <p class="col font-weight-semibold"> <?php echo e($client->address); ?></p>
                            </li>
                        </ul>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="card">
    <div class="card-body">
        <h5 class="mb-3"><?php echo e($client->name); ?>'s Projects</h5>
        
        <table id="data-table" class="table table-inverse">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Status</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                    <?php $__currentLoopData = $client->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($item->name); ?>

                        </td>
                        <td>
                            <?php echo e($item->category->name); ?>

                        </td>
                        <td>
                            
                            <span class="badge 
                            <?php switch($item->status):
                                        case ('not started'): ?>
                                            badge-default
                                            <?php break; ?>
                                        <?php case ('in progress'): ?>
                                            badge-info
                                            <?php break; ?>
                                        <?php case ('on hold'): ?>
                                            badge-warning
                                            <?php break; ?>
                                        <?php case ('cancled'): ?>
                                            badge-dange
                                            <?php break; ?>
                                        <?php default: ?>
                                            badge-success    
                                    <?php endswitch; ?>
                            ">
                                <?php echo e($item->status); ?>

                            </span>
                        </td>
                        <td>
                            <span class="badge badge-default">
                                <?php echo e(Carbon\Carbon::parse($item->updated_at)->format('d-M-Y')); ?>

                            </span>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
            
        </table>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- page js -->
<script src="<?php echo e(asset('backend/vendors/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/vendors/datatables/dataTables.bootstrap.min.js')); ?>"></script>

<script>
    

$('#data-table').DataTable();


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/clients/show.blade.php ENDPATH**/ ?>