<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($task->name); ?> - Task</title>
    
    <meta name="description" content="Deadline - <?php echo e(Carbon\Carbon::parse($task->end_date)->format('d-M-Y')); ?>">
    <link rel="canonical" href="<?php echo Request::url(); ?>" />
    
    
    
    <meta property="og:type" content="article" >
    
    
    <meta property="og:title" content="<?php echo e($task->name ?? ''); ?>" >
    
    
    <meta property="og:description" content="Deadline - <?php echo e(Carbon\Carbon::parse($task->end_date)->format('d-M-Y')); ?>" >
    
    
    <meta property="og:image" content="<?php echo e(asset('backend/images/logo/favicon.png')); ?>" >
    
    
    <meta property="og:url" content="<?php echo Request::url(); ?>" >
    
    
    <meta property="og:site_name" content="PM" >
    
    
    <meta property="og:image:width" content="1000" >
    
    
    <meta property="og:image:height" content="667" >
    <!-- Styles -->
    <link href="<?php echo e(asset('backend/css/app.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/css/style.css')); ?>" rel="stylesheet">

    <style>
        @media  screen and (max-width: 480px) {
            .justify-content-between {
                display: block !important;
            }
            .justify-content-between .badge-pill{
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
    
    <div class="container mt-5">
        <div class="row justify-content-center">
            
            <div class="col-md-7">
                <div class="card">
                    <div class="card-header mt-3">
                        <div class="d-flex justify-content-between">
                            <div class="media align-items-center">
                                
                                <div class="m-l-1">
                                    <h4 class="m-b-0"><?php echo e($task->name); ?></h4>
                                </div>
                            </div>
                            <div>
                                <span class="badge badge-pill 
                                    <?php switch($task->status):
                                        case ('incomplete'): ?>
                                            badge-danger
                                            <?php break; ?>
                                        <?php default: ?>
                                            badge-success    
                                    <?php endswitch; ?>
                                    " style="text-transform:capitalize;"><?php echo e($task->status); ?></span>
                                <span class="badge badge-pill badge-info" style="text-transform:capitalize;"><?php echo e($task->priority); ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card-body">
                        <table class="table table-responsive">
                            <thead>
                                <tr>
                                    <th>Project</th>
                                    <th>Start Date</th>
                                    <th>Deadline</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td scope="row"><?php echo e($task->project->name); ?></td>
                                    <td><?php echo e(Carbon\Carbon::parse($task->start_date)->format('d-M-Y')); ?></td>
                                    <td><?php echo e(Carbon\Carbon::parse($task->end_date)->format('d-M-Y')); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer">
                        <span class="text-dark font-weight-semibold m-r-10 m-b-5">Assigned Member: </span>
                        <?php $__currentLoopData = $task->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <span class="badge badge-pill 
                        <?php if($user->utype == 'MAN'): ?>
                            badge-warning
                        <?php elseif($user->utype == 'ADM'): ?>
                            badge-danger
                        <?php else: ?>
                            badge-default
                        <?php endif; ?>
                        ">
                        <?php echo e($user->name); ?>

                        </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Core JS -->
    <script src="<?php echo e(asset('backend/js/app.min.js')); ?>"></script>
</body>
</html><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/share_task.blade.php ENDPATH**/ ?>