
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div class="media align-items-center">
                                
                                <div class="m-l-1">
                                    <h4 class="m-b-0"><?php echo e($project->name); ?></h4>
                                    <p><?php echo e($project->category->name); ?></p>
                                </div>
                            </div>
                            <div>
                                <span class="badge badge-pill 
                                    <?php switch($project->status):
                                        case ('not started'): ?>
                                            badge-default
                                            <?php break; ?>
                                        <?php case ('in progress'): ?>
                                            badge-info
                                            <?php break; ?>
                                        <?php case ('on hold'): ?>
                                            badge-warning
                                            <?php break; ?>
                                        <?php case ('cancled'): ?>
                                            badge-dange
                                            <?php break; ?>
                                        <?php default: ?>
                                            badge-success    
                                    <?php endswitch; ?>
                                    " style="text-transform:capitalize;"><?php echo e($project->status); ?></span>
                                <span class="badge badge-pill badge-info" style="text-transform:capitalize;"><?php echo e($project->priority); ?></span>
                            </div>
                        </div>
                        
                        <div class="d-md-flex m-t-30 align-items-center justify-content-between">
                            <div class="d-flex align-items-center m-t-10">
                                <span class="text-dark font-weight-semibold m-r-10 m-b-5">Team: </span>
                                <?php $__currentLoopData = $project->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                <span class="badge badge-pill 
                                <?php if($user->utype == 'MAN'): ?>
                                    badge-warning
                                <?php elseif($user->utype == 'ADM'): ?>
                                    badge-danger
                                <?php else: ?>
                                    badge-default
                                <?php endif; ?>
                                "><?php echo e($user->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="m-t-10">
                                <span class="font-weight-semibold m-r-10 m-b-5 text-dark">Start Date: </span>
                                <span><?php echo e(Carbon\Carbon::parse($project->start_date)->format('d-M-Y')); ?> </span><br>
                                <span class="font-weight-semibold m-r-10 m-b-5 text-dark">Deadline: </span>
                                <span><?php echo e(Carbon\Carbon::parse($project->end_date)->format('d-M-Y')); ?> </span>
                            </div>
                        </div>
                    </div>
                    <div class="m-t-30">
                        <ul class="nav nav-tabs" id="myTab">
                            <li class="nav-item">
                                <a class="nav-link active"  href="<?php echo e(route('projects.show', $project->id)); ?>">Overview</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('projects.index')); ?>/<?php echo e($project->id); ?>/tasks">Tasks</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('projects.index')); ?>/<?php echo e($project->id); ?>/comments">Comments</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('projects.index')); ?>/<?php echo e($project->id); ?>/attachments">Attachments</a>
                            </li>
                        </ul>
                        <div class="tab-content m-t-15 p-25">
                            <div class="tab-pane fade show active" id="project-details">
                                <p>
                                    <?php echo $project->description; ?>

                                </p>

                                <hr>
                                <?php if(!empty($project->client)): ?>
                                <div class="col-md-5 mb-2">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="m-t-10 text-center">
                                                <div class="avatar avatar-image" style="height: 100px; width: 100px;">
                                                    <img src="
                                                    <?php if(!empty($project->client->asset)): ?>
                                                    <?php echo e(asset('backend/images/clients/'. $project->client->asset)); ?>

                                                    <?php else: ?>
                                                    <?php echo e(asset('backend/images/client_logo.png')); ?>

                                                    <?php endif; ?>
                                                    
                                                    " alt="<?php echo e($project->client->name); ?>">
                                                </div>
                                                
                                                <div class="dropdown dropdown-animated " style="
                                                display: inline;
                                                position: absolute;
                                                float: right;
                                                right: 20px;
                                                top: 10px;
                                                ">
                                                    <a class="text-gray font-size-18" href="javascript:void(0);" data-toggle="dropdown">
                                                        <i class="anticon anticon-setting"></i>
                                                    </a>
                                                    <div class="dropdown-menu">
                                                        <a href="<?php echo e(route('clients.show', $project->client->id)); ?>" class="dropdown-item" type="button">
                                                            <i class="anticon anticon-eye"></i>
                                                            <span class="m-l-10">View</span>
                                                        </a>
                                                        <?php if (\Illuminate\Support\Facades\Blade::check('manager')): ?>
                                                        <a href="<?php echo e(route('clients.edit', $project->client->id)); ?>" class="dropdown-item" type="button">
                                                            <i class="anticon anticon-edit"></i>
                                                            <span class="m-l-10">Edit</span>
                                                        </a>
                                                        <button class="dropdown-item" type="button" onclick="if(confirm('Are you sure you want to delete this data?')){document.getElementById('delete-form<?php echo e($project->client->id); ?>').submit(); }">
                                                            <i class="anticon anticon-delete"></i>
                                                            <span class="m-l-10">Delete</span>
                                                        </button>
                                                        <form style="display: none;" id="delete-form<?php echo e($project->client->id); ?>" method="POST" action="<?php echo e(route('clients.destroy', $project->client->id)); ?>" >
                                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                        </form>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <h4 class="m-t-30"><?php echo e($project->client->name); ?></h4>
                                                <p><?php echo e($project->client->email); ?></p>
                                                <small><?php echo e(count($project->client->projects)); ?> Projects</small>
                                            </div>
                                            <div class="text-center m-t-30">
                                                <a href="tel:<?php echo e($project->client->phone); ?>" class="btn btn-primary btn-tone">
                                                    <i class="anticon anticon-mail"></i>
                                                    <span class="m-l-5">Call Now</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- Content Wrapper END -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/projects/show/index.blade.php ENDPATH**/ ?>