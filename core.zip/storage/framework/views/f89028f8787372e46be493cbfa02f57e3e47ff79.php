<div class="side-nav">
    <div class="side-nav-inner">
        <ul class="side-nav-menu scrollable">
            <li class="nav-item dropdown">
                <a href="<?php echo e(route('home')); ?>">
                    <span class="icon-holder">
                        <i class="anticon anticon-dashboard"></i>
                    </span>
                    <span class="title">Dashboard</span>
                </a>
            </li>

            <li class="nav-item dropdown">
                <a class="dropdown-toggle" href="javascript:void(0);">
                    <span class="icon-holder">
                        <i class="anticon anticon-inbox"></i>
                    </span>
                    <span class="title">Projects</span>
                    <span class="arrow">
                        <i class="arrow-icon"></i>
                    </span>
                </a>
                <ul class="dropdown-menu">
                    <li class="<?php echo e(Route::is('projects.*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('projects.index')); ?>">All Projects</a>
                    </li>
                    <?php if (\Illuminate\Support\Facades\Blade::check('manager')): ?>
                    <li class="">
                        <a href="<?php echo e(route('projects.create')); ?>">Create New</a>
                    </li>
                    <li class="<?php echo e(Route::is('categories.*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('categories.index')); ?>">Project Categories</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>

            <li class="nav-item dropdown">
                <a class="dropdown-toggle" href="javascript:void(0);">
                    <span class="icon-holder">
                        <i class="anticon anticon-profile"></i>
                    </span>
                    <span class="title">Tasks</span>
                    <span class="arrow">
                        <i class="arrow-icon"></i>
                    </span>
                </a>
                <ul class="dropdown-menu">
                    <li class="<?php echo e(Route::is('tasks.*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('tasks.index')); ?>">All Tasks</a>
                    </li>
                    <?php if (\Illuminate\Support\Facades\Blade::check('manager')): ?>
                    <li class="">
                        <a href="<?php echo e(route('tasks.create.one')); ?>">Create New</a>
                    </li>
                    <li class="<?php echo e(Route::is('task-categories.*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('task-categories.index')); ?>">Task Categories</a>
                    </li>
                    <li class="">
                        <a href="">Timer</a>
                    </li>
                    <?php endif; ?>
                    
                </ul>
            </li>

            <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
            <li class="nav-item dropdown">
                <a class="dropdown-toggle" href="javascript:void(0);">
                    <span class="icon-holder">
                        <i class="anticon anticon-team"></i>
                    </span>
                    <span class="title">Employees</span>
                    <span class="arrow">
                        <i class="arrow-icon"></i>
                    </span>
                </a>
                <ul class="dropdown-menu">
                    <li class="<?php echo e(Route::is('users') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('users')); ?>">All Employees</a>
                    </li>                
                    <li class=" <?php echo e(Route::is('departments.*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('departments.index')); ?>">Departments</a>
                    </li>
                    
                </ul>
            </li>

            
            <li class="nav-item  <?php echo e(Route::is('activity.log') ? 'active' : ''); ?>">
                <a class="" href="<?php echo e(route('activity.log')); ?>">
                    <span class="icon-holder">
                        <i class="anticon anticon-hourglass"></i>
                    </span>
                    <span class="title">Activity Log</span>
                </a>
            </li>

            <?php endif; ?>

            
            <?php if (\Illuminate\Support\Facades\Blade::check('manager')): ?>
            
            <li class="nav-item  <?php echo e(Route::is('clients.*') ? 'active' : ''); ?>">
                <a class="" href="<?php echo e(route('clients.index')); ?>">
                    <span class="icon-holder">
                        <i class="anticon anticon-user"></i>
                    </span>
                    <span class="title">Clients</span>
                </a>
            </li>
            <?php endif; ?>

        </ul>
    </div>
</div><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/layouts/parts/nav.blade.php ENDPATH**/ ?>