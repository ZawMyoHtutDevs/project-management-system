
<?php $__env->startSection('style'); ?>
<link href="https://unpkg.com/dropzone@6.0.0-beta.1/dist/dropzone.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div class="media align-items-center">
                                
                                <div class="m-l-1">
                                    <h4 class="m-b-0"><?php echo e($project->name); ?></h4>
                                    <p><?php echo e($project->category->name); ?></p>
                                </div>
                            </div>
                            <div>
                                <span class="badge badge-pill 
                                    <?php switch($project->status):
                                        case ('not started'): ?>
                                            badge-default
                                            <?php break; ?>
                                        <?php case ('in progress'): ?>
                                            badge-info
                                            <?php break; ?>
                                        <?php case ('on hold'): ?>
                                            badge-warning
                                            <?php break; ?>
                                        <?php case ('cancled'): ?>
                                            badge-dange
                                            <?php break; ?>
                                        <?php default: ?>
                                            badge-success    
                                    <?php endswitch; ?>
                                    " style="text-transform:capitalize;"><?php echo e($project->status); ?></span>
                                <span class="badge badge-pill badge-info" style="text-transform:capitalize;"><?php echo e($project->priority); ?></span>
                            </div>
                        </div>
                        
                        <div class="d-md-flex m-t-30 align-items-center justify-content-between">
                            <div class="d-flex align-items-center m-t-10">
                                <span class="text-dark font-weight-semibold m-r-10 m-b-5">Team: </span>
                                <?php $__currentLoopData = $project->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="m-r-5 m-b-5" href="javascript:void(0);" data-toggle="tooltip" title="<?php echo e($user->name); ?>">
                                    <div class="avatar avatar-image"
                                    style="width: 30px; height: 30px;
                                    <?php if($user->utype == 'MAN'): ?>
                                    border: 2px solid gold;
                                    <?php elseif($user->utype == 'ADM'): ?>
                                    border: 2px solid red;
                                    <?php endif; ?>
                                    "
                                    >
                                        <img src="<?php echo e(asset('backend/images/user.png')); ?>" alt="<?php echo e($user->name); ?>">
                                    </div>
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="m-t-10">
                                <span class="font-weight-semibold m-r-10 m-b-5 text-dark">Start Date: </span>
                                <span><?php echo e(Carbon\Carbon::parse($project->start_date)->format('d-M-Y')); ?> </span><br>
                                <span class="font-weight-semibold m-r-10 m-b-5 text-dark">Deadline: </span>
                                <span><?php echo e(Carbon\Carbon::parse($project->end_date)->format('d-M-Y')); ?> </span>
                            </div>
                        </div>
                    </div>
                    <div class="m-t-30">
                        <ul class="nav nav-tabs" id="myTab">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab"  href="#project-details">Overview</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#project-details-tasks">Tasks (8)</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#project-details-comments" id="tab">Comments</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#project-details-attachment">Attachment</a>
                            </li>
                        </ul>
                        <div class="tab-content m-t-15 p-25">
                            <div class="tab-pane fade show active" id="project-details">
                                <p>
                                    <?php echo e($project->description); ?>

                                </p>

                                <hr>
                                <?php if(!empty($project->client)): ?>
                                <div class="col-md-5 mb-2">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="m-t-10 text-center">
                                                <div class="avatar avatar-image" style="height: 100px; width: 100px;">
                                                    <img src="
                                                    <?php if(!empty($project->client->asset)): ?>
                                                    <?php echo e(asset('backend/images/clients/'. $project->client->asset)); ?>

                                                    <?php else: ?>
                                                    <?php echo e(asset('backend/images/client_logo.png')); ?>

                                                    <?php endif; ?>
                                                    
                                                    " alt="<?php echo e($project->client->name); ?>">
                                                </div>
                                                
                                                <div class="dropdown dropdown-animated " style="
                                                display: inline;
                                                position: absolute;
                                                float: right;
                                                right: 20px;
                                                top: 10px;
                                                ">
                                                    <a class="text-gray font-size-18" href="javascript:void(0);" data-toggle="dropdown">
                                                        <i class="anticon anticon-setting"></i>
                                                    </a>
                                                    <div class="dropdown-menu">
                                                        <a href="<?php echo e(route('clients.show', $project->client->id)); ?>" class="dropdown-item" type="button">
                                                            <i class="anticon anticon-eye"></i>
                                                            <span class="m-l-10">View</span>
                                                        </a>
                                                        <?php if (\Illuminate\Support\Facades\Blade::check('manager')): ?>
                                                        <a href="<?php echo e(route('clients.edit', $project->client->id)); ?>" class="dropdown-item" type="button">
                                                            <i class="anticon anticon-edit"></i>
                                                            <span class="m-l-10">Edit</span>
                                                        </a>
                                                        <button class="dropdown-item" type="button" onclick="if(confirm('Are you sure you want to delete this data?')){document.getElementById('delete-form<?php echo e($project->client->id); ?>').submit(); }">
                                                            <i class="anticon anticon-delete"></i>
                                                            <span class="m-l-10">Delete</span>
                                                        </button>
                                                        <form style="display: none;" id="delete-form<?php echo e($project->client->id); ?>" method="POST" action="<?php echo e(route('clients.destroy', $project->client->id)); ?>" >
                                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                        </form>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <h4 class="m-t-30"><?php echo e($project->client->name); ?></h4>
                                                <p><?php echo e($project->client->email); ?></p>
                                                <small><?php echo e(count($project->client->projects)); ?> Projects</small>
                                            </div>
                                            <div class="text-center m-t-30">
                                                <a href="tel:<?php echo e($project->client->phone); ?>" class="btn btn-primary btn-tone">
                                                    <i class="anticon anticon-mail"></i>
                                                    <span class="m-l-5">Call Now</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>

                            </div>
                            <div class="tab-pane fade" id="project-details-tasks">
                                <div class="checkbox m-b-20">
                                    <input id="task-1" type="checkbox">
                                    <label for="task-1">Irish skinny, grinder affogato</label>
                                </div>
                                <div class="checkbox m-b-20">
                                    <input id="task-2" type="checkbox">
                                    <label for="task-2">Let us wax poetic about the beauty of the cheeseburger.</label>
                                </div>
                                <div class="checkbox m-b-20">
                                    <input id="task-3" type="checkbox">
                                    <label for="task-3">I'm gonna build me an airport</label>
                                </div>
                                <div class="checkbox m-b-20">
                                    <input id="task-4" type="checkbox" checked="">
                                    <label for="task-4">Efficiently unleash cross-media information</label>
                                </div>
                                <div class="checkbox m-b-20">
                                    <input id="task-5" type="checkbox" checked="">
                                    <label for="task-5">Here's the story of a man named Brady</label>
                                </div>
                                <div class="checkbox m-b-20">
                                    <input id="task-6" type="checkbox" checked="">
                                    <label for="task-6">Bugger bag egg's old boy willy jolly</label>
                                </div>
                                <div class="checkbox m-b-20">
                                    <input id="task-7" type="checkbox" checked="">
                                    <label for="task-7">Hand-crafted exclusive finest tote bag Ettinger</label>
                                </div>
                                <div class="checkbox m-b-20">
                                    <input id="task-8" type="checkbox" checked="">
                                    <label for="task-8">I'll be sure to note that in my log</label>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="project-details-comments">
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item p-h-0">
                                        <div class="media m-b-1">
                                            <div class="media-body m-l-20">
                                                <h6 class="m-b-0">
                                                    <a href="" class="text-dark">Lillian Stone</a>
                                                </h6>
                                                <span class="font-size-13 text-gray">28th Jul 2018</span>
                                            </div>
                                        </div>
                                        <p>The palatable sensation we lovingly refer to as The Cheeseburger has a distinguished and illustrious history. It was born from humble roots, only to rise to well-seasoned greatness.</p>
                                    </li>

                                    <li class="list-group-item p-h-0">
                                        <div class="media m-b-1">
                                            <div class="media-body m-l-20">
                                                <h6 class="m-b-0">
                                                    <a href="" class="text-dark">Lillian Stone</a>
                                                </h6>
                                                <span class="font-size-13 text-gray">28th Jul 2018</span>
                                            </div>
                                        </div>
                                        <p>The palatable sensation we lovingly refer to as The Cheeseburger has a distinguished and illustrious history. It was born from humble roots, only to rise to well-seasoned greatness.</p>
                                    </li>

                                    <li class="list-group-item p-h-0">
                                        <div class="media m-b-1">
                                            <div class="media-body m-l-20">
                                                <h6 class="m-b-0">
                                                    <a href="" class="text-dark">Lillian Stone</a>
                                                </h6>
                                                <span class="font-size-13 text-gray">28th Jul 2018</span>
                                            </div>
                                        </div>
                                        <p>The palatable sensation we lovingly refer to as The Cheeseburger has a distinguished and illustrious history. It was born from humble roots, only to rise to well-seasoned greatness.</p>
                                    </li>
                                </ul>
                            </div>
                            <div class="tab-pane fade" id="project-details-attachment">
                                <div class="m-3">
                                    <div id="file" class="dropzone"></div>
                                </div>

                                <?php $__currentLoopData = $project->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="file" style="min-width: 200px;">
                                    <div class="media align-items-center">
                                        <?php if($item->extension == "png" || $item->extension == "jpg" || $item->extension == "jpeg" || $item->extension == "gif" ): ?>
                                        <div class="avatar avatar-icon avatar-blue rounded m-r-15">
                                            <i class="anticon anticon-file-image font-size-20"></i>
                                        </div>

                                        <?php elseif($item->extension == "docx" || $item->extension == "txt"): ?>
                                        <div class="avatar avatar-icon avatar-cyan rounded m-r-15">
                                            <i class="anticon anticon-file-text font-size-20"></i>
                                        </div>

                                        <?php elseif($item->extension == "pdf"): ?>
                                        <div class="avatar avatar-icon avatar-volcano rounded m-r-15">
                                            <i class="anticon anticon-file-pdf font-size-20"></i>
                                        </div>

                                        <?php else: ?>
                                        <div class="avatar avatar-icon avatar-gold rounded m-r-15">
                                            <i class="anticon anticon-file-exclamation font-size-20"></i>
                                        </div>

                                        <?php endif; ?>
                                        

                                        <div>
                                            <h6 class="mb-0"><?php echo e($item->asset); ?></h6>
                                            <span class="font-size-13 text-muted">
                                                <?php
                                                    if ($item->size >= 1073741824) {
                                                        $mbSize = number_format($item->size / 1073741824, 2) . ' GB';
                                                    } elseif ($item->size >= 1048576) {
                                                        $mbSize = number_format($item->size / 1048576, 2) . ' MB';
                                                    } elseif ($item->size >= 1024) {
                                                        $mbSize = number_format($item->size / 1024, 2) . ' KB';
                                                    } elseif ($item->size > 1) {
                                                        $mbSize = $item->size . ' bytes';
                                                    } elseif ($item->size == 1) {
                                                        $mbSize = '1 byte';
                                                    } else {
                                                        $mbSize = '0 bytes';
                                                    }
                                                ?>
                                                <?php echo e($mbSize); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- Content Wrapper END -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://unpkg.com/dropzone@6.0.0-beta.1/dist/dropzone-min.js"></script>
<script>
    var drop = new Dropzone('#file', {
      createImageThumbnails: true,
      addRemoveLinks: true,
      url: "<?php echo e(route('attachment.store', $project->id)); ?>",
      headers: {
        'X-CSRF-TOKEN': document.head.querySelector('meta[name="csrf-token"]').content
      }
    });

    // $('#myTab a[href="#project-details-comments"]').tab('show')
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/projects/show.blade.php ENDPATH**/ ?>