<?php echo e($slot); ?>

<?php /**PATH D:\MyFile\Backend\project-management-system\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>