
<?php $__env->startSection('style'); ?>
<!-- page css -->
<link href="<?php echo e(asset('backend/vendors/datatables/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">

<style>
    #data-table_filter input{
        max-width: 200px !important;
    }
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header">
    <h2 class="header-title">Accounts List</h2>
    <div class="header-sub-title">
        <nav class="breadcrumb breadcrumb-dash">
            <a href="<?php echo e(route('home')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Dashboard</a>
            <span class="breadcrumb-item active">Accounts</span>
        </nav>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        <span class="sr-only">Close</span>
    </button>
    <?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?>

<div class="row">
    
    <div class="col-md-12">
        <div class="card">
            <div class="card-header mt-3 h3"><?php echo e(__('Accounts')); ?> 
                <button class="btn btn-primary m-r-5 float-right" data-toggle="modal" data-target="#adduser" >Add <i class="anticon anticon-plus-square"></i></button>
            </div>
            
            <div class="card-body">
                <table id="data-table" class="table" class="table table-inverse ">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Department</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->name); ?></td>
                            <td><?php echo e($data->email); ?></td>
                            <td>
                                <?php switch($data->utype):
                                    case ('ADM'): ?>
                                    <span class="badge badge-danger">Admin</span>
                                        <?php break; ?>
                                    <?php case ('MAN'): ?>
                                    <span class="badge badge-warning">Manager</span>
                                        <?php break; ?>
                                    <?php default: ?>
                                    <span class="badge badge-info">Employee</span>
                                <?php endswitch; ?>
                                
                            </td>
                            <td>
                                <?php if(!empty($data->department)): ?>
                                    <?php echo e($data->department->name); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                
                                
                                <a href="<?php echo e(route('users.detail', $data->id)); ?>" class="btn btn-icon btn-hover btn-sm btn-rounded pull-right text-primary">
                                    <i class="anticon anticon-edit"></i>
                                </a>
                                
                                <?php if(Auth::user()->id != $data->id): ?>
                                
                                <button class="btn btn-icon btn-hover btn-sm btn-rounded text-danger" type="submit" onclick="if(confirm('Are you sure you want to delete this data?')){document.getElementById('delete-form<?php echo e($data->id); ?>').submit(); }">
                                    <i class="anticon anticon-delete"></i>
                                </button>
                                <form id="delete-form<?php echo e($data->id); ?>" method="POST" action="<?php echo e(route('delete.user', $data->id)); ?>" >
                                    <?php echo csrf_field(); ?>
                                </form>
                                <?php endif; ?>
                                
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    
                    
                </table>
            </div>
        </div>
    </div>
</div>


<?php echo $__env->make('auth.add_user_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- page js -->
<script src="<?php echo e(asset('backend/vendors/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/vendors/datatables/dataTables.bootstrap.min.js')); ?>"></script>

<script>
    
    
    $('#data-table').DataTable();
    
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/auth/user.blade.php ENDPATH**/ ?>