
<?php $__env->startSection('style'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-header no-gutters">
    <div class="d-md-flex align-items-md-center justify-content-between">
        <div class="media m-v-10 align-items-center">
            <div class="avatar avatar-image avatar-lg">
                <img src="<?php echo e(asset('backend/images/user.png')); ?>" alt="">
            </div>
            <div class="media-body m-l-15">
                <h4 class="m-b-0">Welcome back, <?php echo e($user->name); ?>!</h4>
                <span class="text-gray"><?php echo e($user->email); ?></span>
            </div>
        </div>
        <div class="d-md-flex align-items-center d-none">
            <div class="media align-items-center m-r-40 m-v-5">
                <div class="font-size-27">
                    <i class="text-primary anticon anticon-profile"></i>
                </div>
                <div class="d-flex align-items-center m-l-10">
                    <h2 class="m-b-0 m-r-5"><?php echo e(count($user->tasks)); ?></h2>
                    <span class="text-gray">Tasks</span>
                </div>
            </div>
            <div class="media align-items-center m-r-40 m-v-5">
                <div class="font-size-27">
                    <i class="text-success  anticon anticon-appstore"></i>
                </div>
                <div class="d-flex align-items-center m-l-10">
                    <h2 class="m-b-0 m-r-5"><?php echo e(count($user->projects)); ?></h2>
                    <span class="text-gray">Projects</span>
                </div>
            </div>
            <div class="media align-items-center m-v-5">
                <div class="font-size-27">
                    <i class="text-danger anticon anticon-issues-close"></i>
                </div>
                <div class="d-flex align-items-center m-l-10">
                    <h2 class="m-b-0 m-r-5"><?php echo e(count($user->tasks->where('status', '=', 'incomplete'))); ?></h2>
                    <span class="text-gray">Pending Tasks</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Projects</h5>
                    <div>
                        <a href="<?php echo e(route('projects.index')); ?>" class="btn btn-default btn-sm">View All</a> 
                    </div>
                </div>
                <div class="table-responsive m-t-30">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Project</th>
                                <th>Tasks</th>
                                <th>Status</th>
                                <th>Progress</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $user->projects->slice(0, 6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="media align-items-center">
                                        
                                        <div class="">
                                            <h5 class="m-b-0"><?php echo e($item->name); ?></h5>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span><?php echo e(count($item->tasks)); ?> Tasks</span>
                                </td>
                                <td>
                                    <span class="badge badge-pill 
                                            <?php switch($item->status):
                                            case ('not started'): ?>
                                            badge-default
                                            <?php break; ?>
                                            <?php case ('in progress'): ?>
                                            badge-info
                                            <?php break; ?>
                                            <?php case ('on hold'): ?>
                                            badge-warning
                                            <?php break; ?>
                                            <?php case ('cancled'): ?>
                                            badge-dange
                                            <?php break; ?>
                                            <?php default: ?>
                                            badge-success    
                                            <?php endswitch; ?>
                                            " style="text-transform:capitalize;"><?php echo e($item->status); ?>

                                        </span>
                                
                                </td>
                                <td>
                                <div class="d-flex align-items-center">
                                    <?php
                                    if(count($item->tasks)){
                                        $countPercent = count($item->tasks->where('status', '=', 'completed')) / count($item->tasks);
                                        $percentage = $countPercent * 100;
                                    }
                                    ?>
                                    <div class="progress progress-sm w-100 m-b-0">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo e($percentage ?? '0'); ?>%"></div>
                                    </div>
                                    <div class="m-l-10">
                                        <?php echo e($percentage ?? '0'); ?>%
                                    </div>
                                </div>
                            </td>
                        </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Assigned tasks</h5>
                    <div>
                        <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-default btn-sm">View All</a> 
                    </div>
                </div>
                <div class="table-responsive m-t-30">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Task</th>
                                <th>Status</th>
                                <th>Due Date</th>
                                <th>Project</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $user->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="span">
                                    <h5 class="m-b-0"><?php echo e($item->name); ?></h5>
                                </div>
                            </td>
                            <td>
                                <span class="badge badge-pill 
                                            <?php switch($item->status):
                                            case ('incomplete'): ?>
                                            badge-danger
                                            <?php break; ?>
                                            <?php default: ?>
                                            badge-success    
                                            <?php endswitch; ?>
                                            " style="text-transform:capitalize;">
                                            <?php echo e($item->status); ?>

                                        </span>
                            </td>
                            <td>
                                <p class="text-success"
                                <?php
                                $today_time = strtotime(Carbon\Carbon::now()->format('d-M-Y'));
                                $expire_time = strtotime(Carbon\Carbon::parse($item->end_date)->format('d-M-Y'));
                                ?> 
                                <?php if($expire_time < $today_time): ?>
                                style="color:red  !important;"
                                <?php endif; ?>
                                >
                                <?php echo e(Carbon\Carbon::parse($item->end_date)->format('d-M-Y')); ?>

                                </p>
                            </td>
                            <td>
                                <span><?php echo e($item->project->name); ?></span>
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/dashboard/employee.blade.php ENDPATH**/ ?>