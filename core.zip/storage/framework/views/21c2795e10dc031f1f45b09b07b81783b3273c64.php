
<?php $__env->startSection('style'); ?>
<!-- select css -->
<link href="<?php echo e(asset('backend/vendors/select2/select2.css')); ?>"  rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header">
    <h2 class="header-title"><?php echo e($task->name); ?></h2>
    <div class="header-sub-title">
        <nav class="breadcrumb breadcrumb-dash">
            <a href="<?php echo e(route('home')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Dashboard</a>
            <a class="breadcrumb-item" href="<?php echo e(route('tasks.index')); ?>">Tasks</a>
            <span class="breadcrumb-item active">Update Task</span>
        </nav>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        <span class="sr-only">Close</span>
    </button>
    <?php echo e(Session::get('error')); ?>

</div>
<?php endif; ?>

<div class="row">
    <div class="col-md-9">
        <div class="card">
            
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('tasks.update', $task->id)); ?>">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    
                    <div class="form-group">
                        <input type="text" name="name" id="name" class="form-control form-control-lg <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Task Name" value="<?php echo e(old('name') ?? $task->name); ?>" autocomplete="Task Name" required>
                        
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="row">
                        <div class="col-4">
                            <div class="form-group">
                                <label for="task_category_id">Task Category</label>
                                <select class="select2" name="task_category_id" id="task_category_id">
                                    <option value="<?php echo e($task->taskCategory->id); ?>"><?php echo e($task->taskCategory->name); ?></option>
                                    <?php $__currentLoopData = $taskCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat_data->id); ?>"><?php echo e($cat_data->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-8">
                            <div class="form-group">
                                <label for="users">Assign Members</label>
                                <select class="select2" name="users[]" id="users" multiple="multiple">
                                    <option value="">Select</option>
                                    <?php $__currentLoopData = $task->project->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user_data->id); ?>"
                                            <?php $__currentLoopData = $task->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($data->id == $user_data->id): ?>
                                                    selected
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            ><?php echo e($user_data->name); ?>

                                        <?php if($user_data->utype == 'MAN'): ?>
                                            - (Manager)
                                        <?php endif; ?>
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="start_date">Start Date</label>
                                <input type="date"
                                class="form-control" name="start_date" id="start_date" aria-describedby="start_date" required value="<?php echo e(old('start_date') ?? $task->start_date); ?>">
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="end_date">Deatline</label>
                                <input type="date"
                                class="form-control" name="end_date" id="end_date" aria-describedby="end_date" value="<?php echo e(old('end_date') ?? $task->end_date); ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="status">Task Status</label>
                                <select class="form-control" name="status" id="status" style="text-transform:capitalize;" required>
                                    <?php if(old('status') || $task->status): ?>
                                    <option value="<?php echo e(old('status') ?? $task->status); ?>" selected><?php echo e(old('status') ?? $task->status); ?></option>
                                    <?php endif; ?>
                                    <option value="incomplete">incomplete</option>
                                    <option value="completed">completed</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-6">
                            <div class="form-group">
                                <label for="priority">Task Priority</label>
                                <select class="form-control" name="priority" id="priority" style="text-transform:capitalize;" required>
                                    <?php if(old('priority') || $task->priority): ?>
                                    <option value="<?php echo e(old('priority') ?? $task->priority); ?>" selected><?php echo e(old('priority') ?? $task->priority); ?></option>
                                    <?php endif; ?>
                                    <option value="high">high</option>
                                    <option value="medium">medium</option>
                                    <option value="low">low</option>
                                </select>
                            </div>
                        </div>
                        
                    </div>
                    
                    
                    
                    <textarea name="description" id="description" cols="30" rows="10">
                        <?php echo old('description') ?? $task->description; ?>

                    </textarea>

                    <hr>
                    
                    <button type='submit' class='btn btn-primary m-r-5 ml-2 float-right' ><span class='m-l-5'>Add Task</span><i class='anticon anticon-right'></i></button>

                    <a href='<?php echo e(route('tasks.create.one')); ?>' class='btn btn-default m-r-5 ml-2 float-right' ><i class="anticon anticon-left"></i><span class='m-l-5'>Back</span></a>

                </form>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div class="media">
                        
                        <div class="m-l-1">
                            <h5 class="m-b-0"><?php echo e($task->project->name); ?></h5>
                        </div>
                    </div>
                    <div class="dropdown dropdown-animated scale-left">
                        <a class="text-gray font-size-18" href="javascript:void(0);" data-toggle="dropdown">
                            <i class="anticon anticon-setting"></i>
                        </a>
                        <div class="dropdown-menu">
                            <a href="<?php echo e(route('projects.show', $task->project->id)); ?>" class="dropdown-item" type="button">
                                <i class="anticon anticon-eye"></i>
                                <span class="m-l-10">View</span>
                            </a>
                            
                        </div>
                    </div>
                </div>
                <p class="mt-3">
                    <span class="font-weight-semibold m-r-10 m-b-5 text-dark">Start Date: </span>
                        <span><?php echo e(Carbon\Carbon::parse($task->project->start_date)->format('d-M-Y')); ?> </span><br>
                        <span class="font-weight-semibold m-r-10 m-b-5 text-dark">Deadline: </span>
                        <span><?php echo e(Carbon\Carbon::parse($task->project->end_date)->format('d-M-Y')); ?> </span>
                </p>
                
                <div class="m-t-20">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            
                            <span class="badge badge-pill 
                            <?php switch($task->project->status):
                                case ('not started'): ?>
                                    badge-default
                                    <?php break; ?>
                                <?php case ('in progress'): ?>
                                    badge-info
                                    <?php break; ?>
                                <?php case ('on hold'): ?>
                                    badge-warning
                                    <?php break; ?>
                                <?php case ('cancled'): ?>
                                    badge-dange
                                    <?php break; ?>
                                <?php default: ?>
                                    badge-success    
                            <?php endswitch; ?>
                            " style="text-transform:capitalize;"><?php echo e($task->project->status); ?></span>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>


</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- select js -->
<script src="<?php echo e(asset('backend/vendors/select2/select2.min.js')); ?>"></script>
<script src="//cdn.ckeditor.com/4.19.0/standard/ckeditor.js"></script>

<script>
    $('.select2').select2();
    
    
    CKEDITOR.replace( 'description',{
        
    } 
    );
    
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/tasks/update.blade.php ENDPATH**/ ?>