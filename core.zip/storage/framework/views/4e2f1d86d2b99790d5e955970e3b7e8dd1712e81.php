

<?php $__env->startSection('style'); ?>
<!-- select css -->
<link href="<?php echo e(asset('backend/vendors/select2/select2.css')); ?>"  rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



<div class="page-header no-gutters">
    <div class="row align-items-md-center">
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-5">
                    <h3>Projects</h3>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="text-md-right m-v-10">
                <span class="text-muted pr-3 pt-2 p">Total Result: <?php echo e(count($notifications)); ?></span>
                
                
                
                <button class="btn btn-default m-r-5 " data-toggle="modal" data-target="#filter" >
                    <i class="anticon anticon-filter"></i>
                    <span class="m-l-5">Filter</span>
                </button>
                
                <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-warning m-r-5 ml-2 " >
                    <i class="anticon anticon-plus"></i>
                    <span class="m-l-5">Delete By Date</span>
                </a>
                
            </div>
        </div>
    </div>
</div>        


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        <span class="sr-only">Close</span>
    </button>
    <?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        <span class="sr-only">Close</span>
    </button>
    <?php echo e(Session::get('error')); ?>

</div>
<?php endif; ?>


<div class="container-fluid">
    
    <div class="row">
        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <li class="timeline-item pb-0">
                            <div class="timeline-item-head">
                                <div class="avatar avatar-icon bg-white">
                                    <?php if($item->read_at != ''): ?>
                                    <i class="anticon anticon-issues-close font-size-22 text-success"></i>
                                    <?php else: ?>
                                    <i class="anticon anticon-info-circle font-size-22 text-warning"></i>
                                    <?php endif; ?>
                                    

                                    
                                </div>
                            </div>
                            <div class="timeline-item-content">
                                <div class="m-l-10">
                                    <p class="m-b-0">
                                        <?php
                                            $body = json_decode($item->data, true);
                                        ?>
                                        <span class="m-l-5"><?php echo e($body['data']); ?></span>
                                    </p>
                                    <span class="text-muted font-size-13">
                                        <i class="anticon anticon-clock-circle"></i>
                                        
                                        4 Min ago
                                    </span>
                                </div>
                            </div>
                        </li>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <br>
    
    
    <?php echo $notifications->appends(array("created_at" => request()->get('created_at','') ))->links(); ?>

</div>


<?php echo $__env->make('activity_filter_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- select js -->
<script src="<?php echo e(asset('backend/vendors/select2/select2.min.js')); ?>"></script>

<script>
    $('.select2').select2();
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/activity_log.blade.php ENDPATH**/ ?>