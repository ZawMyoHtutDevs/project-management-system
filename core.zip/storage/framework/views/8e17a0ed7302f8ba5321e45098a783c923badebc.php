
<?php $__env->startSection('style'); ?>
<!-- select css -->
<link href="<?php echo e(asset('backend/vendors/select2/select2.css')); ?>"  rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header">
    <h2 class="header-title">Add New Project</h2>
    <div class="header-sub-title">
        <nav class="breadcrumb breadcrumb-dash">
            <a href="<?php echo e(route('home')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Dashboard</a>
            <a class="breadcrumb-item" href="<?php echo e(route('projects.index')); ?>">Projects</a>
            <span class="breadcrumb-item active">New Project</span>
        </nav>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('projects.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?> 
                    

                    <div class="form-group">
                        <input type="text" name="name" id="name" class="form-control form-control-lg <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Project Name" value="<?php echo e(old('name')); ?>" autocomplete="Project Name" required>
                        
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="category_id">Project Category</label>
                                <select class="select2" name="category_id" id="category_id">
                                    <option value="">Select</option>
                                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($cat_data->id); ?>"><?php echo e($cat_data->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                        </div>
    
                        <div class="col-6">
                            <div class="form-group">
                                <label for="client_id">Client</label>
                                <select class="select2" name="client_id" id="client_id">
                                    <option value="">Select</option>
                                  <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cli_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cli_data->id); ?>"><?php echo e($cli_data->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                              <label for="start_date">Start Date</label>
                              <input type="date"
                                class="form-control" name="start_date" id="start_date" aria-describedby="start_date" required value="<?php echo e(old('start_date')); ?>">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="end_date">Deatline</label>
                                <input type="date"
                                  class="form-control" name="end_date" id="end_date" aria-describedby="end_date" value="<?php echo e(old('end_date')); ?>">
                              </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="users">Project Members</label>
                        <select class="select2" name="users[]" id="users" multiple="multiple">
                            <option value="">Select</option>
                          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user_data->id); ?>"><?php echo e($user_data->name); ?>

                            <?php if($user_data->utype == 'MAN'): ?>
                                - (Manager)
                            <?php endif; ?>
                            </option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>

                    <hr>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="status">Project Status</label>
                                <select class="form-control" name="status" id="status" style="text-transform:capitalize;" required>
                                  <?php if(old('status')): ?>
                                      <option value="<?php echo e(old('status')); ?>" selected><?php echo e(old('status')); ?></option>
                                  <?php endif; ?>
                                  <option value="not started">not started</option>
                                  <option value="in progress">in progress</option>
                                  <option value="on hold">on hold</option>
                                  <option value="cancled">cancled</option>
                                  <option value="finished">finished</option>
                                </select>
                              </div>
                        </div>

                        <div class="col-6">
                            <div class="form-group">
                                <label for="priority">Project Priority</label>
                                <select class="form-control" name="priority" id="priority" style="text-transform:capitalize;" required>
                                  <?php if(old('priority')): ?>
                                      <option value="<?php echo e(old('priority')); ?>" selected><?php echo e(old('priority')); ?></option>
                                  <?php endif; ?>
                                  <option value="high">high</option>
                                  <option value="medium">medium</option>
                                  <option value="low">low</option>
                                </select>
                            </div>
                        </div>

                    </div>
                    
                    
                    <div class="form-group">
                        <label for="">Description</label>
                        <textarea name="description" class="form-control  <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="description" rows="3"><?php echo old('description'); ?></textarea>
                    </div>
                    
                    
                    <button type="submit" class="btn btn-primary float-right">Add Project</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- select js -->
<script src="<?php echo e(asset('backend/vendors/select2/select2.min.js')); ?>"></script>
<script src="//cdn.ckeditor.com/4.19.0/standard/ckeditor.js"></script>

<script>
    $('.select2').select2();
    
    
    CKEDITOR.replace( 'description',{
        
    } 
    );
    
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyFile\Backend\project-management-system\resources\views/projects/create.blade.php ENDPATH**/ ?>